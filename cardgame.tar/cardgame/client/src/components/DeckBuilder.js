import React, { useState } from 'react';
import { CARDS } from '../cards';
import { CardFace } from './Card';

export default function DeckBuilder({ onSubmit, playerName }) {
  const [deck, setDeck] = useState([]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [hoveredCard, setHoveredCard] = useState(null);

  const filtered = CARDS.filter(c => {
    if (filter === 'monster' && c.cardType !== 'monster') return false;
    if (filter === 'spell' && c.cardType !== 'spell') return false;
    if (search && !c.name.includes(search)) return false;
    return true;
  });

  const addCard = (card) => {
    if (deck.length >= 30) return;
    setDeck(prev => [...prev, { ...card, _deckId: Date.now() + Math.random() }]);
  };

  const removeCard = (deckId) => {
    setDeck(prev => prev.filter(c => c._deckId !== deckId));
  };

  const handleSubmit = () => {
    if (deck.length < 25) return alert('덱은 최소 25장이 필요합니다.');
    onSubmit(deck.map(c => c.id));
  };

  const monsterCount = deck.filter(c => c.cardType === 'monster').length;
  const spellCount = deck.filter(c => c.cardType === 'spell').length;

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #05020f 0%, #0a0520 100%)',
      color: '#ddd',
      fontFamily: "'Noto Sans KR', sans-serif",
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* 헤더 */}
      <div style={{
        padding: '16px 24px',
        background: 'linear-gradient(90deg, #1a0a35, #0d0520)',
        borderBottom: '1px solid #3a1a60',
        display: 'flex',
        alignItems: 'center',
        gap: 16,
      }}>
        <div style={{ fontFamily: "'Black Han Sans'", fontSize: 22, color: '#c89aff' }}>
          🎴 덱 빌더
        </div>
        <div style={{ color: '#aaa', fontSize: 13 }}>{playerName}의 덱</div>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 13, color: '#aaa' }}>
            몬스터 {monsterCount} / 마법 {spellCount}
          </span>
          <div style={{
            background: deck.length >= 25 ? 'linear-gradient(90deg, #4a1a80, #7a2acc)' : '#333',
            color: deck.length >= 25 ? '#fff' : '#666',
            border: 'none',
            borderRadius: 8,
            padding: '8px 20px',
            cursor: deck.length >= 25 ? 'pointer' : 'default',
            fontFamily: "'Black Han Sans'",
            fontSize: 14,
          }} onClick={handleSubmit}>
            {deck.length}/30 — 덱 완성!
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* 카드 목록 */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* 필터 */}
          <div style={{
            padding: '10px 16px',
            background: '#0a0520',
            borderBottom: '1px solid #2a1050',
            display: 'flex',
            gap: 10,
            alignItems: 'center',
          }}>
            {['all', 'monster', 'spell'].map(f => (
              <button key={f} onClick={() => setFilter(f)} style={{
                background: filter === f ? '#4a1a80' : '#1a0a35',
                color: filter === f ? '#fff' : '#aaa',
                border: `1px solid ${filter === f ? '#7a3acc' : '#3a1a60'}`,
                borderRadius: 6,
                padding: '4px 12px',
                cursor: 'pointer',
                fontSize: 12,
                fontFamily: "'Noto Sans KR'",
              }}>
                {f === 'all' ? '전체' : f === 'monster' ? '몬스터' : '마법'}
              </button>
            ))}
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="카드 이름 검색..."
              style={{
                background: '#0d0525',
                border: '1px solid #3a1a60',
                borderRadius: 6,
                padding: '4px 10px',
                color: '#ddd',
                fontSize: 12,
                fontFamily: "'Noto Sans KR'",
                outline: 'none',
                marginLeft: 'auto',
                width: 160,
              }}
            />
          </div>

          {/* 카드 그리드 */}
          <div style={{
            flex: 1,
            overflowY: 'auto',
            padding: 16,
            display: 'flex',
            flexWrap: 'wrap',
            gap: 10,
            alignContent: 'flex-start',
          }}>
            {filtered.map(card => (
              <div
                key={card.id}
                style={{ position: 'relative' }}
                onMouseEnter={() => setHoveredCard(card)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <CardFace
                  card={card}
                  small
                  onClick={() => addCard(card)}
                  dimmed={deck.length >= 30}
                />
                <div style={{
                  position: 'absolute',
                  bottom: -6,
                  right: -4,
                  background: '#4a1a80',
                  color: '#fff',
                  borderRadius: 10,
                  fontSize: 9,
                  padding: '1px 5px',
                  pointerEvents: 'none',
                }}>
                  {deck.filter(c => c.id === card.id).length}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 오른쪽: 내 덱 + 카드 상세 */}
        <div style={{
          width: 300,
          background: '#07031a',
          borderLeft: '1px solid #2a1050',
          display: 'flex',
          flexDirection: 'column',
        }}>
          {/* 카드 상세 */}
          {hoveredCard && (
            <div style={{
              padding: 16,
              borderBottom: '1px solid #2a1050',
              background: '#0d0525',
            }}>
              <div style={{ fontFamily: "'Black Han Sans'", fontSize: 14, color: '#c89aff', marginBottom: 6 }}>
                {hoveredCard.name}
              </div>
              {hoveredCard.cardType === 'monster' && (
                <div style={{ fontSize: 11, color: '#aaa', marginBottom: 4 }}>
                  ★{hoveredCard.level} | {hoveredCard.race} | ATK {hoveredCard.atk} / DEF {hoveredCard.def}
                </div>
              )}
              <div style={{ fontSize: 10, color: '#ccc', lineHeight: 1.5 }}>
                {hoveredCard.effect}
              </div>
            </div>
          )}

          {/* 덱 목록 */}
          <div style={{ flex: 1, overflowY: 'auto', padding: 8 }}>
            <div style={{ fontSize: 11, color: '#888', padding: '4px 8px', marginBottom: 4 }}>
              내 덱 ({deck.length}/30) {deck.length < 25 && <span style={{ color: '#ff6644' }}>— 최소 25장</span>}
            </div>
            {deck.map((card) => (
              <div key={card._deckId} style={{
                display: 'flex',
                alignItems: 'center',
                padding: '4px 8px',
                borderRadius: 4,
                gap: 8,
                cursor: 'pointer',
                background: 'transparent',
                transition: 'background 0.1s',
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#1a0a35'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              onClick={() => removeCard(card._deckId)}
              >
                <div style={{
                  width: 10,
                  height: 10,
                  borderRadius: '50%',
                  background: card.cardType === 'monster' ? '#7a44cc' : '#2a9a4a',
                  flexShrink: 0,
                }} />
                <div style={{ flex: 1, fontSize: 11, color: '#ccc', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {card.name}
                </div>
                <div style={{ fontSize: 9, color: '#666' }}>✕</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
