import React, { useState } from 'react';

const LEVEL_STARS = (n) => '★'.repeat(Math.min(n, 12));

function CardFace({ card, small, selected, onClick, disabled, glowing, dimmed }) {
  const isMonster = card.cardType === 'monster';
  const [hovered, setHovered] = useState(false);

  const bgGrad = isMonster
    ? 'linear-gradient(145deg, #1c1040 0%, #0e0820 60%, #1a0e35 100%)'
    : 'linear-gradient(145deg, #0a2015 0%, #051208 60%, #0e2018 100%)';

  const borderColor = selected
    ? '#ffe566'
    : glowing
    ? '#ff6622'
    : isMonster
    ? '#5a3fa0'
    : '#2a7a4a';

  const sizeStyle = small
    ? { width: 72, height: 98, fontSize: 8 }
    : { width: 120, height: 168, fontSize: 10 };

  return (
    <div
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        ...sizeStyle,
        background: bgGrad,
        border: `2px solid ${borderColor}`,
        borderRadius: 6,
        cursor: disabled ? 'default' : 'pointer',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: selected
          ? '0 0 18px #ffe566, 0 0 6px #ffe566 inset'
          : glowing
          ? '0 0 14px #ff6622'
          : hovered && !disabled
          ? '0 0 10px rgba(120,90,220,0.7)'
          : '0 2px 6px rgba(0,0,0,0.6)',
        opacity: dimmed ? 0.45 : 1,
        transition: 'box-shadow 0.15s, opacity 0.15s, transform 0.1s',
        transform: hovered && !disabled && !dimmed ? 'translateY(-3px) scale(1.03)' : 'none',
        flexShrink: 0,
        userSelect: 'none',
      }}
    >
      {/* 헤더 */}
      <div style={{
        background: isMonster
          ? 'linear-gradient(90deg, #2d1f66, #3a2878)'
          : 'linear-gradient(90deg, #0d3d1f, #1a6633)',
        padding: small ? '2px 4px' : '3px 6px',
        borderBottom: `1px solid ${borderColor}44`,
      }}>
        <div style={{
          color: '#fff',
          fontFamily: "'Black Han Sans', sans-serif",
          fontSize: small ? 7 : 9,
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
          textShadow: '0 1px 3px rgba(0,0,0,0.8)',
        }}>
          {card.name}
        </div>
      </div>

      {/* 레벨 별 */}
      <div style={{
        padding: small ? '1px 4px' : '2px 6px',
        color: '#ffd700',
        fontSize: small ? 6 : 8,
        letterSpacing: -1,
      }}>
        {LEVEL_STARS(card.level || 0)}
      </div>

      {/* 아트 영역 */}
      <div style={{
        margin: small ? '0 4px' : '0 6px',
        height: small ? 36 : 66,
        background: isMonster
          ? 'linear-gradient(135deg, #120b28, #1e1040, #0e0820)'
          : 'linear-gradient(135deg, #041208, #0a1e10, #051a0c)',
        borderRadius: 3,
        border: `1px solid ${borderColor}33`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        position: 'relative',
      }}>
        <div style={{
          fontSize: small ? 20 : 36,
          opacity: 0.6,
        }}>
          {isMonster ? getMonsterEmoji(card) : '✨'}
        </div>
        {/* HP bar if instance */}
        {card.currentHP !== undefined && !small && (
          <div style={{
            position: 'absolute',
            bottom: 2,
            left: 3,
            right: 3,
            height: 4,
            background: '#111',
            borderRadius: 2,
            overflow: 'hidden',
          }}>
            <div style={{
              width: `${Math.max(0, Math.min(100, (card.currentHP / card.maxHP) * 100))}%`,
              height: '100%',
              background: card.currentHP / card.maxHP > 0.5 ? '#22cc66' : card.currentHP / card.maxHP > 0.25 ? '#ffaa00' : '#ff3333',
              borderRadius: 2,
              transition: 'width 0.3s',
            }} />
          </div>
        )}
      </div>

      {/* 종족/타입 */}
      {!small && (
        <div style={{
          padding: '2px 6px',
          color: '#aaa',
          fontSize: 7,
          display: 'flex',
          justifyContent: 'space-between',
        }}>
          <span>{card.race || (card.cardType === 'spell' ? '마법' : '')}</span>
          {card.position && (
            <span style={{ color: card.position === 'attack' ? '#ff8844' : '#44aaff' }}>
              {card.position === 'attack' ? '공격' : '방어'}
            </span>
          )}
        </div>
      )}

      {/* ATK / DEF */}
      {isMonster && (
        <div style={{
          padding: small ? '2px 4px' : '2px 6px',
          display: 'flex',
          justifyContent: 'space-between',
          color: '#ddd',
          fontSize: small ? 6.5 : 8.5,
          borderTop: `1px solid ${borderColor}33`,
          marginTop: 'auto',
        }}>
          <span style={{ color: '#ff8866' }}>
            ATK {card.currentATK ?? card.atk ?? 0}
          </span>
          <span style={{ color: '#66aaff' }}>
            DEF {card.currentDEF ?? card.def ?? 0}
          </span>
        </div>
      )}

      {/* 상태 표시 */}
      {card.isNeutralized && (
        <div style={{
          position: 'absolute', inset: 0,
          background: 'rgba(100,0,0,0.55)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: small ? 10 : 16,
        }}>🚫</div>
      )}
      {!card.canAttack && card.isSummoned && isMonster && !small && (
        <div style={{
          position: 'absolute', top: 2, right: 2,
          background: 'rgba(0,0,0,0.7)',
          color: '#888',
          fontSize: 7,
          borderRadius: 3,
          padding: '1px 3px',
        }}>소환됨</div>
      )}
      {card.stacks?.tear > 0 && !small && (
        <div style={{
          position: 'absolute', top: 2, left: 2,
          background: 'rgba(0,80,180,0.85)',
          color: '#aaf',
          fontSize: 7,
          borderRadius: 3,
          padding: '1px 3px',
        }}>💧×{card.stacks.tear}</div>
      )}
    </div>
  );
}

function CardBack({ small }) {
  return (
    <div style={{
      width: small ? 72 : 120,
      height: small ? 98 : 168,
      background: 'linear-gradient(145deg, #1a0a30, #0e0520)',
      border: '2px solid #4a2a80',
      borderRadius: 6,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
    }}>
      <div style={{
        width: small ? 52 : 88,
        height: small ? 72 : 130,
        background: 'repeating-linear-gradient(45deg, #2a1050 0px, #2a1050 3px, #1a0830 3px, #1a0830 6px)',
        borderRadius: 4,
        border: '1px solid #5a3a90',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: small ? 14 : 28,
      }}>
        🎴
      </div>
    </div>
  );
}

function getMonsterEmoji(card) {
  const r = card.race;
  if (r === '갤럭시족') return '🌌';
  if (r === '에일리언족') return '👾';
  if (r === '크리스탈족') return '💎';
  if (r === '정령족') return '🌿';
  if (r === '동물') return '🐾';
  // 이름 기반
  const n = card.name;
  if (n.includes('용준')) return '🐲';
  if (n.includes('이건')) return '⚡';
  if (n.includes('김승유')) return '👤';
  if (n.includes('김연수')) return '🦊';
  if (n.includes('임채환')) return '⚔️';
  return '👹';
}

export { CardFace, CardBack, getMonsterEmoji };
