import React, { useState } from 'react';

export default function Lobby({ onCreateRoom, onJoinRoom, onRefresh, rooms, connected, playerName, setPlayerName }) {
  const [joinCode, setJoinCode] = useState('');
  const [tab, setTab] = useState('create'); // 'create' | 'join'

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(ellipse at 50% 30%, #1a0a35 0%, #07020f 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Noto Sans KR', sans-serif",
      color: '#ddd',
      padding: 20,
    }}>
      {/* 타이틀 */}
      <div style={{ textAlign: 'center', marginBottom: 40 }}>
        <div style={{
          fontFamily: "'Black Han Sans', sans-serif",
          fontSize: 48,
          color: '#c89aff',
          textShadow: '0 0 30px rgba(180,100,255,0.5), 0 0 60px rgba(180,100,255,0.2)',
          letterSpacing: 4,
          marginBottom: 8,
        }}>
          🎴 카드게임
        </div>
        <div style={{ color: '#665588', fontSize: 13, letterSpacing: 2 }}>
          온라인 멀티플레이어 카드 배틀
        </div>
        <div style={{
          marginTop: 8,
          display: 'inline-block',
          padding: '3px 12px',
          borderRadius: 20,
          background: connected ? 'rgba(0,180,80,0.15)' : 'rgba(180,0,0,0.15)',
          border: `1px solid ${connected ? '#00aa44' : '#aa0000'}`,
          color: connected ? '#44ff88' : '#ff4444',
          fontSize: 11,
        }}>
          {connected ? '● 서버 연결됨' : '● 서버 연결 중...'}
        </div>
      </div>

      {/* 메인 카드 */}
      <div style={{
        background: 'linear-gradient(145deg, #120830, #0a0520)',
        border: '1px solid #3a1a60',
        borderRadius: 16,
        padding: 32,
        width: '100%',
        maxWidth: 420,
        boxShadow: '0 8px 40px rgba(0,0,0,0.6)',
      }}>
        {/* 닉네임 */}
        <div style={{ marginBottom: 24 }}>
          <label style={{ fontSize: 12, color: '#888', display: 'block', marginBottom: 6 }}>닉네임</label>
          <input
            value={playerName}
            onChange={e => setPlayerName(e.target.value)}
            placeholder="닉네임을 입력하세요"
            style={{
              width: '100%',
              background: '#0d0525',
              border: '1px solid #3a1a60',
              borderRadius: 8,
              padding: '10px 14px',
              color: '#fff',
              fontSize: 14,
              fontFamily: "'Noto Sans KR'",
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
        </div>

        {/* 탭 */}
        <div style={{ display: 'flex', marginBottom: 20, borderRadius: 8, overflow: 'hidden', border: '1px solid #3a1a60' }}>
          {['create', 'join'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              flex: 1,
              padding: '10px',
              background: tab === t ? '#3a1a60' : 'transparent',
              color: tab === t ? '#fff' : '#888',
              border: 'none',
              cursor: 'pointer',
              fontSize: 13,
              fontFamily: "'Noto Sans KR'",
              transition: 'background 0.2s',
            }}>
              {t === 'create' ? '방 만들기' : '방 참가'}
            </button>
          ))}
        </div>

        {tab === 'create' ? (
          <button
            onClick={() => onCreateRoom(playerName)}
            disabled={!connected || !playerName.trim()}
            style={{
              width: '100%',
              padding: '14px',
              background: connected && playerName.trim()
                ? 'linear-gradient(90deg, #5a1aaa, #8a2acc)'
                : '#2a1a40',
              color: connected && playerName.trim() ? '#fff' : '#555',
              border: 'none',
              borderRadius: 8,
              cursor: connected && playerName.trim() ? 'pointer' : 'default',
              fontSize: 15,
              fontFamily: "'Black Han Sans'",
              letterSpacing: 2,
              transition: 'background 0.2s',
            }}
          >
            + 새 방 만들기
          </button>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input
              value={joinCode}
              onChange={e => setJoinCode(e.target.value.toUpperCase())}
              placeholder="방 코드 입력 (예: AB3F9)"
              style={{
                background: '#0d0525',
                border: '1px solid #3a1a60',
                borderRadius: 8,
                padding: '10px 14px',
                color: '#fff',
                fontSize: 14,
                fontFamily: 'monospace',
                outline: 'none',
                letterSpacing: 4,
                textAlign: 'center',
              }}
            />
            <button
              onClick={() => onJoinRoom(joinCode, playerName)}
              disabled={!connected || !playerName.trim() || !joinCode.trim()}
              style={{
                padding: '12px',
                background: connected && playerName.trim() && joinCode.trim()
                  ? 'linear-gradient(90deg, #1a4a7a, #2a6acc)'
                  : '#1a1a2a',
                color: connected && playerName.trim() && joinCode.trim() ? '#fff' : '#555',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer',
                fontSize: 14,
                fontFamily: "'Black Han Sans'",
                letterSpacing: 2,
              }}
            >
              입장 →
            </button>
          </div>
        )}

        {/* 공개 방 목록 */}
        {rooms && rooms.length > 0 && (
          <div style={{ marginTop: 20 }}>
            <div style={{ fontSize: 11, color: '#666', marginBottom: 8 }}>공개 대기 방</div>
            {rooms.map(room => (
              <div key={room.roomId} style={{
                display: 'flex',
                alignItems: 'center',
                padding: '8px 12px',
                background: '#0d0525',
                border: '1px solid #2a1050',
                borderRadius: 6,
                marginBottom: 4,
              }}>
                <span style={{ flex: 1, fontSize: 12 }}>
                  <span style={{ color: '#c89aff', fontFamily: 'monospace' }}>{room.roomId}</span>
                  {' '}{room.host}의 방
                </span>
                <button onClick={() => { setJoinCode(room.roomId); setTab('join'); }} style={{
                  background: '#2a1050',
                  color: '#aaa',
                  border: '1px solid #3a1a60',
                  borderRadius: 4,
                  padding: '3px 8px',
                  cursor: 'pointer',
                  fontSize: 11,
                }}>입장</button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ marginTop: 20, fontSize: 11, color: '#443355', textAlign: 'center' }}>
        덱은 25~30장 · HP 12,000 · 선공 패널티 적용
      </div>
    </div>
  );
}
