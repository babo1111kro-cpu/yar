import React from 'react';

export default function GameOver({ winner, winnerName, myId, reason, onRestart }) {
  const isWinner = winner === myId;

  return (
    <div style={{
      minHeight: '100vh',
      background: isWinner
        ? 'radial-gradient(ellipse at 50% 40%, #1a3a0a 0%, #05100a 100%)'
        : 'radial-gradient(ellipse at 50% 40%, #3a0a0a 0%, #100505 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Noto Sans KR', sans-serif",
      color: '#ddd',
    }}>
      <div style={{
        textAlign: 'center',
        padding: 40,
      }}>
        <div style={{ fontSize: 80, marginBottom: 16 }}>
          {isWinner ? '🏆' : '💀'}
        </div>
        <div style={{
          fontFamily: "'Black Han Sans'",
          fontSize: 48,
          color: isWinner ? '#aaff66' : '#ff6644',
          textShadow: isWinner ? '0 0 30px rgba(100,255,80,0.5)' : '0 0 30px rgba(255,80,60,0.5)',
          marginBottom: 12,
          letterSpacing: 4,
        }}>
          {isWinner ? '승리!' : '패배...'}
        </div>
        <div style={{ color: '#888', fontSize: 14, marginBottom: 8 }}>
          {winnerName} 승리
        </div>
        {reason && (
          <div style={{ color: '#666', fontSize: 12, marginBottom: 24 }}>{reason}</div>
        )}
        <button onClick={onRestart} style={{
          marginTop: 24,
          padding: '14px 40px',
          background: 'linear-gradient(90deg, #3a1a60, #6a2acc)',
          color: '#fff',
          border: 'none',
          borderRadius: 10,
          cursor: 'pointer',
          fontSize: 16,
          fontFamily: "'Black Han Sans'",
          letterSpacing: 2,
        }}>
          처음으로
        </button>
      </div>
    </div>
  );
}
