import React, { useState, useEffect, useRef } from 'react';
import { CardFace, CardBack } from './Card';

// ─── 작은 HP 바 ───
function HPBar({ hp, maxHP, name }) {
  const pct = Math.max(0, Math.min(100, (hp / maxHP) * 100));
  const color = pct > 60 ? '#22cc66' : pct > 30 ? '#ffaa00' : '#ff3333';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ fontSize: 11, color: '#aaa', minWidth: 60, textAlign: 'right' }}>{name}</span>
      <div style={{ flex: 1, height: 10, background: '#111', borderRadius: 5, overflow: 'hidden', border: '1px solid #333' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 5, transition: 'width 0.4s' }} />
      </div>
      <span style={{ fontSize: 11, color, fontFamily: 'monospace', minWidth: 50 }}>{hp.toLocaleString()}</span>
    </div>
  );
}

// ─── 필드 존 (3칸 or 2칸) ───
function FieldZone({ slots, label, onSlotClick, selectedSlot, highlightSlots, small }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <div style={{ fontSize: 9, color: '#666', letterSpacing: 1 }}>{label}</div>
      <div style={{ display: 'flex', gap: 6 }}>
        {slots.map((card, i) => (
          <div
            key={i}
            onClick={() => onSlotClick && onSlotClick(i, card)}
            style={{
              width: small ? 74 : 84,
              height: small ? 100 : 116,
              background: '#0a0520',
              border: `1px dashed ${highlightSlots?.includes(i) ? '#ffe566' : '#2a1050'}`,
              borderRadius: 6,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: onSlotClick ? 'pointer' : 'default',
              position: 'relative',
              transition: 'border-color 0.2s',
              boxShadow: highlightSlots?.includes(i) ? '0 0 8px #ffe56644' : 'none',
            }}
          >
            {card ? (
              <div style={{ transform: card.position === 'defense' ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s' }}>
                <CardFace
                  card={card}
                  small
                  selected={selectedSlot === i}
                  glowing={!card.canAttack === false && card.position === 'attack'}
                />
              </div>
            ) : (
              <div style={{ color: '#2a1050', fontSize: 20 }}>＋</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── 마법/함정 존 ───
function SpellZone({ slots, fieldMagic, onSlotClick, isOpp }) {
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
      {/* 필드 마법 */}
      <div
        onClick={() => onSlotClick && onSlotClick('field', fieldMagic)}
        style={{
          width: 68,
          height: 68,
          background: fieldMagic ? 'linear-gradient(135deg, #0a2015, #1a4020)' : '#040e08',
          border: `1px solid ${fieldMagic ? '#2a7a4a' : '#162a1e'}`,
          borderRadius: 6,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 9,
          color: '#2a5a3a',
          cursor: onSlotClick ? 'pointer' : 'default',
          flexShrink: 0,
        }}
      >
        {fieldMagic ? <CardFace card={fieldMagic} small /> : '필드\n마법'}
      </div>

      {/* 마법/함정 3칸 */}
      {slots.map((card, i) => (
        <div
          key={i}
          onClick={() => onSlotClick && onSlotClick(i, card)}
          style={{
            width: 68,
            height: 68,
            background: card ? 'linear-gradient(135deg, #0a2015, #1a4020)' : '#040e08',
            border: `1px solid ${card ? '#2a7a4a' : '#162a1e'}`,
            borderRadius: 6,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: onSlotClick ? 'pointer' : 'default',
          }}
        >
          {card ? (
            card.isSet && isOpp
              ? <div style={{ fontSize: 20 }}>🂠</div>
              : <CardFace card={card} small />
          ) : (
            <div style={{ fontSize: 20, color: '#162a1e' }}>✦</div>
          )}
        </div>
      ))}
    </div>
  );
}

// ─── 손패 ───
function Hand({ cards, onCardClick, selectedCard, phase }) {
  return (
    <div style={{
      display: 'flex',
      gap: 8,
      padding: '8px 16px',
      overflowX: 'auto',
      minHeight: 120,
      alignItems: 'center',
    }}>
      {cards.map((card, i) => (
        card.hidden
          ? <CardBack key={i} small />
          : <CardFace
              key={card.id + i}
              card={card}
              small
              selected={selectedCard?.id === card.id && selectedCard?._handIdx === i}
              onClick={() => onCardClick && onCardClick(card, i)}
            />
      ))}
    </div>
  );
}

// ─── 메인 게임 필드 ───
export default function GameField({
  state,
  myId,
  oppName,
  myName,
  onAction,
  chatMessages,
  onChat,
  isMyTurn,
  gameLog,
}) {
  const [selectedHandCard, setSelectedHandCard] = useState(null);
  const [selectedFieldCard, setSelectedFieldCard] = useState(null);
  const [actionMenu, setActionMenu] = useState(null); // { card, x, y, options }
  const [tributeMode, setTributeMode] = useState(false);
  const [tributeTargets, setTributeTargets] = useState([]);
  const [pendingSummon, setPendingSummon] = useState(null);
  const [chatInput, setChatInput] = useState('');
  const [showGrave, setShowGrave] = useState(null); // 'my' | 'opp'
  const logRef = useRef(null);

  const me = state?.players?.[myId];
  const oppId = Object.keys(state?.players || {}).find(id => id !== myId);
  const opp = state?.players?.[oppId];

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [gameLog]);

  if (!state || !me || !opp) return (
    <div style={{ color: '#fff', padding: 40, textAlign: 'center', fontFamily: "'Noto Sans KR'" }}>
      게임 로딩 중...
    </div>
  );

  const myMonsters = [...(me.normalZone || [null, null, null]), ...(me.specialZone || [null, null])];
  const oppMonsters = [...(opp.normalZone || [null, null, null]), ...(opp.specialZone || [null, null])];

  // 손패 카드 클릭
  const handleHandCardClick = (card, idx) => {
    if (!isMyTurn) return;
    const c = { ...card, _handIdx: idx };
    if (selectedHandCard?._handIdx === idx) {
      setSelectedHandCard(null);
      setActionMenu(null);
      return;
    }
    setSelectedHandCard(c);
    setSelectedFieldCard(null);

    // 액션 메뉴 옵션 계산
    const options = [];
    if (card.cardType === 'monster') {
      if (card.level <= 5) options.push({ label: '공격 표시 소환', action: () => summonCard(c, 'attack', 'NORMAL') });
      if (card.level <= 5 && card.id !== 'king') options.push({ label: '방어 표시 소환', action: () => summonCard(c, 'defense', 'NORMAL') });
      if (card.level >= 6 || card.id === 'MK') {
        options.push({ label: '특수 소환 준비 (제물 선택)', action: () => startTribute(c) });
      }
    } else if (card.cardType === 'spell' && card.id !== 'hand') {
      options.push({ label: '마법/함정 구역에 세트', action: () => setSpell(c) });
    }
    setActionMenu({ card: c, options });
  };

  const summonCard = (card, position, type) => {
    if (type === 'NORMAL') {
      onAction({ type: 'NORMAL_SUMMON', cardId: card.id, position });
    } else if (type === 'SPECIAL') {
      onAction({
        type: 'SPECIAL_SUMMON',
        cardId: card.id,
        position,
        tributeIds: tributeTargets.map(t => t.instanceId),
      });
      setTributeMode(false);
      setTributeTargets([]);
      setPendingSummon(null);
    }
    setSelectedHandCard(null);
    setActionMenu(null);
  };

  const setSpell = (card) => {
    onAction({ type: 'SET_SPELL', cardId: card.id });
    setSelectedHandCard(null);
    setActionMenu(null);
  };

  const startTribute = (card) => {
    setTributeMode(true);
    setPendingSummon(card);
    setActionMenu(null);
  };

  const handleTributeSelect = (instanceId) => {
    setTributeTargets(prev => {
      const exists = prev.find(t => t.instanceId === instanceId);
      if (exists) return prev.filter(t => t.instanceId !== instanceId);
      const card = myMonsters.find(c => c?.instanceId === instanceId);
      return card ? [...prev, card] : prev;
    });
  };

  const confirmTribute = () => {
    if (!pendingSummon) return;
    // 위치 선택
    const position = window.confirm('공격 표시로 소환하겠습니까? (취소 = 방어 표시)') ? 'attack' : 'defense';
    summonCard(pendingSummon, position, 'SPECIAL');
  };

  // 내 필드 카드 클릭 (공격 선택 또는 표시 변경)
  const handleMyMonsterClick = (idx, card) => {
    if (!isMyTurn || !card) return;
    if (tributeMode) {
      handleTributeSelect(card.instanceId);
      return;
    }
    if (selectedFieldCard?.instanceId === card.instanceId) {
      setSelectedFieldCard(null);
      setActionMenu(null);
      return;
    }
    setSelectedFieldCard(card);
    setSelectedHandCard(null);
    const opts = [];
    if (card.canAttack && card.position === 'attack' && !card.isNeutralized) {
      opts.push({ label: '공격 선택 (대상 선택)', action: () => setActionMenu({ card, options: [], attackMode: true }) });
    }
    if (!card.changedPositionThisTurn) {
      opts.push({ label: '표시 변경', action: () => { onAction({ type: 'CHANGE_POSITION', instanceId: card.instanceId }); setSelectedFieldCard(null); setActionMenu(null); } });
    }
    setActionMenu({ card, options: opts });
  };

  // 상대 카드 클릭 (공격 대상)
  const handleOppMonsterClick = (idx, card) => {
    if (!isMyTurn || !selectedFieldCard) return;
    if (actionMenu?.attackMode) {
      onAction({
        type: 'ATTACK',
        attackerInstanceId: selectedFieldCard.instanceId,
        targetType: 'monster',
        targetInstanceId: card.instanceId,
      });
      setSelectedFieldCard(null);
      setActionMenu(null);
    }
  };

  // 직접 공격
  const directAttack = () => {
    if (!selectedFieldCard) return;
    onAction({
      type: 'ATTACK',
      attackerInstanceId: selectedFieldCard.instanceId,
      targetType: 'player',
    });
    setSelectedFieldCard(null);
    setActionMenu(null);
  };

  // 마법/함정 발동
  const handleSpellActivate = (idx, card) => {
    if (!isMyTurn || !card) return;
    onAction({ type: 'ACTIVATE_SPELL', instanceId: card.instanceId, targetInstanceId: selectedFieldCard?.instanceId });
    setSelectedFieldCard(null);
  };

  const sendChat = () => {
    if (!chatInput.trim()) return;
    onChat(chatInput);
    setChatInput('');
  };

  const isAttackMode = actionMenu?.attackMode;
  const canDirectAttack = isAttackMode && oppMonsters.filter(Boolean).length === 0;

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(ellipse at 50% 50%, #0e0525 0%, #050210 100%)',
      color: '#ddd',
      fontFamily: "'Noto Sans KR', sans-serif",
      display: 'flex',
      flexDirection: 'column',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* 배경 파티클 효과 */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 0,
        background: 'repeating-linear-gradient(0deg, transparent, transparent 40px, rgba(60,30,100,0.03) 40px, rgba(60,30,100,0.03) 41px), repeating-linear-gradient(90deg, transparent, transparent 40px, rgba(60,30,100,0.03) 40px, rgba(60,30,100,0.03) 41px)',
      }} />

      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flex: 1, height: '100vh', overflow: 'hidden' }}>
        {/* ─── 메인 필드 ─── */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: 12, gap: 8, overflow: 'hidden' }}>
          {/* 상대 정보 */}
          <div style={{ padding: '6px 12px', background: 'rgba(100,0,0,0.15)', borderRadius: 8, border: '1px solid #3a0a0a' }}>
            <HPBar hp={opp.hp} maxHP={opp.maxHP || 12000} name={oppName || '상대'} />
            <div style={{ fontSize: 10, color: '#666', marginTop: 2 }}>
              덱 {opp.deckCount || 0}장 | 손패 {opp.handCount || 0}장 | 무덤 {opp.graveyard?.length || 0}장
            </div>
          </div>

          {/* 상대 손패 */}
          <div style={{ display: 'flex', gap: 4, justifyContent: 'center', height: 52 }}>
            {Array.from({ length: opp.handCount || 0 }).map((_, i) => (
              <CardBack key={i} small />
            ))}
          </div>

          {/* 상대 마법/함정 */}
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <SpellZone
              slots={opp.spellTrapZone || [null, null, null]}
              fieldMagic={opp.fieldMagicZone}
              isOpp={true}
            />
          </div>

          {/* 상대 몬스터 존 */}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            <FieldZone
              slots={opp.normalZone || [null, null, null]}
              label="일반"
              onSlotClick={isAttackMode ? handleOppMonsterClick : undefined}
              highlightSlots={isAttackMode ? [0, 1, 2] : []}
              small
            />
            <FieldZone
              slots={opp.specialZone || [null, null]}
              label="특수"
              onSlotClick={isAttackMode ? handleOppMonsterClick : undefined}
              highlightSlots={isAttackMode ? [0, 1] : []}
              small
            />
          </div>

          {/* 구분선 */}
          <div style={{ border: 'none', borderTop: '1px solid #2a1050', margin: '4px 0', position: 'relative' }}>
            <div style={{
              position: 'absolute', top: -10, left: '50%', transform: 'translateX(-50%)',
              background: '#0e0525', padding: '0 12px', color: '#4a2a80', fontSize: 11,
            }}>
              {isMyTurn ? '⚔️ 내 턴' : '⏳ 상대 턴'} | {Math.ceil(state.turn / 1)} 페이즈
            </div>
          </div>

          {/* 내 몬스터 존 */}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            <FieldZone
              slots={me.normalZone || [null, null, null]}
              label="일반"
              onSlotClick={handleMyMonsterClick}
              selectedSlot={selectedFieldCard ? (me.normalZone || []).findIndex(c => c?.instanceId === selectedFieldCard.instanceId) : -1}
              highlightSlots={tributeMode ? [0, 1, 2] : []}
              small
            />
            <FieldZone
              slots={me.specialZone || [null, null]}
              label="특수"
              onSlotClick={handleMyMonsterClick}
              selectedSlot={selectedFieldCard ? (me.specialZone || []).findIndex(c => c?.instanceId === selectedFieldCard.instanceId) : -1}
              highlightSlots={tributeMode ? [0, 1] : []}
              small
            />
          </div>

          {/* 내 마법/함정 */}
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <SpellZone
              slots={me.spellTrapZone || [null, null, null]}
              fieldMagic={me.fieldMagicZone}
              onSlotClick={isMyTurn ? handleSpellActivate : undefined}
              isOpp={false}
            />
          </div>

          {/* 내 정보 */}
          <div style={{ padding: '6px 12px', background: 'rgba(0,60,120,0.15)', borderRadius: 8, border: '1px solid #0a1a3a' }}>
            <HPBar hp={me.hp} maxHP={me.maxHP || 12000} name={myName || '나'} />
            <div style={{ fontSize: 10, color: '#666', marginTop: 2 }}>
              덱 {me.deckCount || 0}장 | 무덤 {me.graveyard?.length || 0}장
              {me.normalSummonedThisTurn && <span style={{ color: '#ff8844', marginLeft: 8 }}>일반 소환 완료</span>}
            </div>
          </div>

          {/* 내 손패 */}
          <div style={{ background: 'rgba(0,0,0,0.3)', borderRadius: 8, border: '1px solid #1a0a35', minHeight: 80 }}>
            <Hand
              cards={me.hand || []}
              onCardClick={handleHandCardClick}
              selectedCard={selectedHandCard}
            />
          </div>

          {/* 액션 버튼 */}
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
            {isMyTurn && !tributeMode && (
              <>
                {!me.isFirstTurn && (
                  <ActionBtn onClick={() => onAction({ type: 'DRAW' })} color="#2a4a8a">
                    📥 드로우
                  </ActionBtn>
                )}
                {canDirectAttack && selectedFieldCard && (
                  <ActionBtn onClick={directAttack} color="#8a2a2a">
                    💥 직접 공격!
                  </ActionBtn>
                )}
                {isAttackMode && (
                  <ActionBtn onClick={() => { setActionMenu(null); setSelectedFieldCard(null); }} color="#444">
                    ✕ 취소
                  </ActionBtn>
                )}
                <ActionBtn onClick={() => onAction({ type: 'END_TURN' })} color="#2a6a2a">
                  ✅ 턴 종료
                </ActionBtn>
                <ActionBtn onClick={() => onAction({ type: 'SURRENDER' })} color="#5a1a1a">
                  🏳 항복
                </ActionBtn>
              </>
            )}
            {tributeMode && (
              <>
                <div style={{ color: '#ffd700', fontSize: 12, padding: '6px 12px', background: '#2a1a00', borderRadius: 6 }}>
                  제물 {tributeTargets.length}장 선택 중 — 파괴할 아군 카드를 클릭
                </div>
                <ActionBtn onClick={confirmTribute} color="#7a3a00">
                  ⚡ 특수 소환!
                </ActionBtn>
                <ActionBtn onClick={() => { setTributeMode(false); setTributeTargets([]); setPendingSummon(null); }} color="#444">
                  취소
                </ActionBtn>
              </>
            )}
          </div>

          {/* 컨텍스트 메뉴 */}
          {actionMenu && actionMenu.options?.length > 0 && !isAttackMode && (
            <div style={{
              position: 'fixed', bottom: 200, left: '50%', transform: 'translateX(-50%)',
              background: '#100820',
              border: '1px solid #4a2a80',
              borderRadius: 8,
              padding: 8,
              display: 'flex',
              gap: 6,
              zIndex: 100,
              boxShadow: '0 4px 20px rgba(0,0,0,0.8)',
            }}>
              <div style={{ fontSize: 11, color: '#888', padding: '4px 8px', fontFamily: "'Black Han Sans'" }}>
                {actionMenu.card?.name}
              </div>
              {actionMenu.options.map((opt, i) => (
                <button key={i} onClick={opt.action} style={{
                  background: '#3a1a60',
                  color: '#fff',
                  border: '1px solid #6a3aaa',
                  borderRadius: 6,
                  padding: '6px 12px',
                  cursor: 'pointer',
                  fontSize: 11,
                  fontFamily: "'Noto Sans KR'",
                  whiteSpace: 'nowrap',
                }}>
                  {opt.label}
                </button>
              ))}
              <button onClick={() => { setActionMenu(null); setSelectedHandCard(null); setSelectedFieldCard(null); }} style={{
                background: '#2a1a2a',
                color: '#888',
                border: '1px solid #3a1a3a',
                borderRadius: 6,
                padding: '6px 10px',
                cursor: 'pointer',
                fontSize: 11,
              }}>✕</button>
            </div>
          )}
        </div>

        {/* ─── 오른쪽 패널 ─── */}
        <div style={{
          width: 240,
          background: '#07031a',
          borderLeft: '1px solid #1a0a35',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
          {/* 게임 로그 */}
          <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <div style={{ padding: '8px 12px', borderBottom: '1px solid #1a0a35', fontSize: 11, color: '#666' }}>
              📜 게임 로그
            </div>
            <div ref={logRef} style={{
              flex: 1,
              overflowY: 'auto',
              padding: 8,
              fontSize: 10,
              lineHeight: 1.6,
              color: '#aaa',
            }}>
              {(gameLog || []).map((msg, i) => (
                <div key={i} style={{
                  padding: '2px 4px',
                  borderRadius: 3,
                  background: i === (gameLog?.length || 0) - 1 ? 'rgba(100,60,180,0.1)' : 'transparent',
                  color: msg.includes('파괴') ? '#ff7766' : msg.includes('소환') ? '#aaffaa' : msg.includes('공격') ? '#ffaa66' : '#aaa',
                }}>
                  {msg}
                </div>
              ))}
            </div>
          </div>

          {/* 채팅 */}
          <div style={{ borderTop: '1px solid #1a0a35' }}>
            <div style={{ padding: '4px 8px', fontSize: 10, color: '#555' }}>💬 채팅</div>
            <div style={{ maxHeight: 100, overflowY: 'auto', padding: '0 8px', fontSize: 10 }}>
              {(chatMessages || []).map((m, i) => (
                <div key={i} style={{ marginBottom: 2, color: '#888' }}>
                  <span style={{ color: '#c89aff' }}>{m.from}: </span>{m.message}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', padding: 6, gap: 4 }}>
              <input
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendChat()}
                placeholder="메시지..."
                style={{
                  flex: 1,
                  background: '#0d0525',
                  border: '1px solid #2a1050',
                  borderRadius: 4,
                  color: '#ddd',
                  padding: '3px 6px',
                  fontSize: 10,
                  fontFamily: "'Noto Sans KR'",
                  outline: 'none',
                }}
              />
              <button onClick={sendChat} style={{
                background: '#3a1a60',
                color: '#fff',
                border: 'none',
                borderRadius: 4,
                padding: '3px 8px',
                cursor: 'pointer',
                fontSize: 10,
              }}>→</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActionBtn({ children, onClick, color }) {
  const [h, setH] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        background: h ? color + 'dd' : color + '99',
        color: '#fff',
        border: `1px solid ${color}`,
        borderRadius: 6,
        padding: '6px 14px',
        cursor: 'pointer',
        fontSize: 11,
        fontFamily: "'Noto Sans KR'",
        transition: 'background 0.15s',
      }}
    >
      {children}
    </button>
  );
}
