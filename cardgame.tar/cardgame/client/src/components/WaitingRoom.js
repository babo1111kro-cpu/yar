import React from 'react';

export default function WaitingRoom({ roomId, playerName, players, deckSubmitted, onSubmitDeck, waiting }) {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(ellipse at 50% 30%, #1a0a35 0%, #07020f 100%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: "'Noto Sans KR', sans-serif",
      color: '#ddd',
      padding: 20,
    }}>
      <div style={{
        background: 'linear-gradient(145deg, #120830, #0a0520)',
        border: '1px solid #3a1a60',
        borderRadius: 16,
        padding: 40,
        width: '100%',
        maxWidth: 420,
        textAlign: 'center',
        boxShadow: '0 8px 40px rgba(0,0,0,0.6)',
      }}>
        <div style={{ fontFamily: "'Black Han Sans'", fontSize: 24, color: '#c89aff', marginBottom: 8 }}>
          대기실
        </div>
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 11, color: '#666', marginBottom: 4 }}>방 코드</div>
          <div style={{
            fontSize: 32,
            fontFamily: 'monospace',
            letterSpacing: 6,
            color: '#ffd700',
            background: '#0d0525',
            border: '1px solid #3a1a60',
            borderRadius: 8,
            padding: '8px 20px',
            display: 'inline-block',
          }}>
            {roomId}
          </div>
          <div style={{ fontSize: 11, color: '#555', marginTop: 6 }}>
            이 코드를 친구에게 알려주세요
          </div>
        </div>

        {/* 플레이어 목록 */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 11, color: '#666', marginBottom: 8 }}>플레이어 ({players?.length || 0}/2)</div>
          {[0, 1].map(i => (
            <div key={i} style={{
              padding: '10px 16px',
              background: players?.[i] ? '#1a0a35' : '#0a0520',
              border: `1px solid ${players?.[i] ? '#4a2a80' : '#2a1050'}`,
              borderRadius: 8,
              marginBottom: 6,
              display: 'flex',
              alignItems: 'center',
              gap: 10,
            }}>
              <div style={{
                width: 8, height: 8, borderRadius: '50%',
                background: players?.[i] ? '#44ff88' : '#333',
              }} />
              <span style={{ fontSize: 13, color: players?.[i] ? '#ddd' : '#444' }}>
                {players?.[i]?.name || '대기 중...'}
              </span>
              {players?.[i]?.name === playerName && (
                <span style={{ fontSize: 10, color: '#7a4acc', marginLeft: 'auto' }}>나</span>
              )}
            </div>
          ))}
        </div>

        {/* 덱 제출 버튼 */}
        {!deckSubmitted ? (
          <button
            onClick={onSubmitDeck}
            disabled={players?.length < 2}
            style={{
              width: '100%',
              padding: '14px',
              background: players?.length >= 2
                ? 'linear-gradient(90deg, #5a1aaa, #8a2acc)'
                : '#2a1a40',
              color: players?.length >= 2 ? '#fff' : '#555',
              border: 'none',
              borderRadius: 8,
              cursor: players?.length >= 2 ? 'pointer' : 'default',
              fontSize: 14,
              fontFamily: "'Black Han Sans'",
              letterSpacing: 2,
            }}
          >
            덱 구성하기 →
          </button>
        ) : (
          <div style={{
            padding: 14,
            background: 'rgba(0,180,80,0.1)',
            border: '1px solid #00aa44',
            borderRadius: 8,
            color: '#44ff88',
            fontSize: 13,
          }}>
            ✓ 덱 제출 완료! {waiting ? '상대방 대기 중...' : '게임 시작!'}
          </div>
        )}
      </div>
    </div>
  );
}
