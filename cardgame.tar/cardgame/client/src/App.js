import React, { useState, useCallback, useRef } from 'react';
import { useWebSocket } from './useWebSocket';
import Lobby from './components/Lobby';
import WaitingRoom from './components/WaitingRoom';
import DeckBuilder from './components/DeckBuilder';
import GameField from './components/GameField';
import GameOver from './components/GameOver';

// screen: 'lobby' | 'waiting' | 'deckbuilder' | 'game' | 'gameover'

export default function App() {
  const [screen, setScreen] = useState('lobby');
  const [playerName, setPlayerName] = useState('');
  const [roomId, setRoomId] = useState('');
  const [rooms, setRooms] = useState([]);

  // 방 정보
  const [players, setPlayers] = useState([]);
  const [deckSubmitted, setDeckSubmitted] = useState(false);
  const [waitingForOpp, setWaitingForOpp] = useState(false);

  // 게임 정보
  const [gameState, setGameState] = useState(null);
  const [myPlayerId, setMyPlayerId] = useState(null);
  const [oppName, setOppName] = useState('');
  const [isMyTurn, setIsMyTurn] = useState(false);
  const [gameLog, setGameLog] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);

  // 게임 오버
  const [gameOverInfo, setGameOverInfo] = useState(null);

  // 덱 빌더에서 돌아올 때 쓸 임시 저장
  const pendingDeckRef = useRef(null);

  const handleMessage = useCallback((msg) => {
    switch (msg.type) {
      case 'ROOM_CREATED':
        setRoomId(msg.roomId);
        setMyPlayerId(msg.playerId);
        setPlayers([{ playerId: msg.playerId, name: msg.name }]);
        setScreen('waiting');
        break;

      case 'ROOM_JOINED':
        setMyPlayerId(msg.playerId);
        setScreen('waiting');
        break;

      case 'ROOM_READY':
        setPlayers(msg.players);
        setScreen('waiting');
        break;

      case 'DECK_SUBMITTED':
        setDeckSubmitted(true);
        setWaitingForOpp(true);
        break;

      case 'GAME_START':
        setGameState(msg.state);
        setMyPlayerId(msg.playerId);
        setOppName(msg.opponentName);
        setIsMyTurn(msg.yourTurn);
        setGameLog(['게임 시작!', ...( msg.state?.log || [])]);
        setScreen('game');
        break;

      case 'GAME_UPDATE':
        setGameState(msg.state);
        setIsMyTurn(msg.yourTurn);
        setGameLog(prev => [...prev, ...(msg.log || [])]);
        break;

      case 'GAME_ENDED':
        setGameOverInfo(msg);
        setScreen('gameover');
        break;

      case 'CHAT':
        setChatMessages(prev => [...prev, { from: msg.from, message: msg.message }]);
        break;

      case 'ROOM_LIST':
        setRooms(msg.rooms);
        break;

      case 'ERROR':
        alert(msg.message);
        break;

      default:
        break;
    }
  }, []);

  const { send, connected } = useWebSocket(handleMessage);

  const handleCreateRoom = (name) => {
    if (!name.trim()) return alert('닉네임을 입력하세요.');
    send({ type: 'CREATE_ROOM', name: name.trim() });
  };

  const handleJoinRoom = (rid, name) => {
    if (!name.trim()) return alert('닉네임을 입력하세요.');
    if (!rid.trim()) return alert('방 코드를 입력하세요.');
    send({ type: 'JOIN_ROOM', roomId: rid.trim(), name: name.trim() });
  };

  const handleRefresh = () => {
    send({ type: 'LIST_ROOMS' });
  };

  // 대기실에서 덱 만들기 클릭
  const handleGoToDeckBuilder = () => {
    setScreen('deckbuilder');
  };

  // 덱 빌더에서 완성
  const handleDeckSubmit = (deckIds) => {
    pendingDeckRef.current = deckIds;
    send({ type: 'SUBMIT_DECK', deck: deckIds });
    setDeckSubmitted(true);
    setWaitingForOpp(true);
    setScreen('waiting');
  };

  const handleAction = (action) => {
    send({ type: 'GAME_ACTION', action });
  };

  const handleChat = (message) => {
    send({ type: 'CHAT', message });
  };

  const handleRestart = () => {
    setScreen('lobby');
    setGameState(null);
    setRoomId('');
    setPlayers([]);
    setDeckSubmitted(false);
    setWaitingForOpp(false);
    setGameLog([]);
    setChatMessages([]);
    setGameOverInfo(null);
    setMyPlayerId(null);
  };

  // 로비 진입 시 방 목록 요청
  const handleLobbyMount = () => {
    send({ type: 'LIST_ROOMS' });
  };

  switch (screen) {
    case 'lobby':
      return (
        <Lobby
          onCreateRoom={handleCreateRoom}
          onJoinRoom={handleJoinRoom}
          onRefresh={handleLobbyMount}
          rooms={rooms}
          connected={connected}
          playerName={playerName}
          setPlayerName={setPlayerName}
        />
      );

    case 'waiting':
      return (
        <WaitingRoom
          roomId={roomId}
          playerName={playerName}
          players={players}
          deckSubmitted={deckSubmitted}
          onSubmitDeck={handleGoToDeckBuilder}
          waiting={waitingForOpp}
        />
      );

    case 'deckbuilder':
      return (
        <DeckBuilder
          playerName={playerName}
          onSubmit={handleDeckSubmit}
        />
      );

    case 'game':
      return (
        <GameField
          state={gameState}
          myId={myPlayerId}
          oppName={oppName}
          myName={playerName}
          onAction={handleAction}
          chatMessages={chatMessages}
          onChat={handleChat}
          isMyTurn={isMyTurn}
          gameLog={gameLog}
        />
      );

    case 'gameover':
      return (
        <GameOver
          winner={gameOverInfo?.winner}
          winnerName={gameOverInfo?.winnerName}
          myId={myPlayerId}
          reason={gameOverInfo?.reason}
          onRestart={handleRestart}
        />
      );

    default:
      return null;
  }
}
