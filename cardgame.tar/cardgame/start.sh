#!/bin/bash
echo "🎴 카드게임 서버 & 클라이언트 시작..."

# 서버 시작 (백그라운드)
cd /home/claude/cardgame/server
node index.js &
SERVER_PID=$!
echo "✅ 서버 시작 (PID: $SERVER_PID) — ws://localhost:3001"

# 클라이언트 시작
cd /home/claude/cardgame/client
BROWSER=none npm start

# 종료 시 서버도 정리
kill $SERVER_PID
