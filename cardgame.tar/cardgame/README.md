# 🎴 카드게임 — 온라인 멀티플레이어

유희왕 스타일 커스텀 카드게임. 온라인 2인 대전.

---

## 📁 구조

```
cardgame/
├── server/          ← Node.js WebSocket 서버
│   ├── index.js     ← 서버 진입점
│   ├── gameLogic.js ← 게임 규칙 엔진 (소환, 전투, 효과)
│   └── cards.json   ← 카드 데이터
└── client/          ← React 프론트엔드
    └── src/
        ├── App.js               ← 화면 관리 (로비→대기실→게임)
        ├── useWebSocket.js      ← WebSocket 연결
        ├── cards.js             ← 카드 데이터 (프론트용)
        └── components/
            ├── Lobby.js         ← 로비 (방 만들기/참가)
            ├── WaitingRoom.js   ← 대기실
            ├── DeckBuilder.js   ← 덱 빌더 (25~30장)
            ├── GameField.js     ← 메인 배틀 필드
            ├── Card.js          ← 카드 렌더링 컴포넌트
            └── GameOver.js      ← 게임 종료 화면
```

---

## 🚀 실행 방법

### 1. 서버 실행

```bash
cd server
npm install
node index.js
# → ws://localhost:3001 에서 실행
```

### 2. 클라이언트 실행 (개발 모드)

```bash
cd client
npm install --legacy-peer-deps
npm start
# → http://localhost:3000 에서 실행
```

### 원클릭 실행 (Linux/Mac)

```bash
chmod +x start.sh
./start.sh
```

---

## 🌐 온라인 배포 방법

### 서버 (Render, Railway, VPS 등)
- `server/` 폴더를 Node.js 앱으로 배포
- 환경변수 `PORT` 설정 (기본 3001)

### 클라이언트
- 빌드: `cd client && npm run build`
- `client/.env` 파일 생성:
  ```
  REACT_APP_WS_URL=wss://your-server-url.com
  ```
- `build/` 폴더를 Vercel, Netlify, GitHub Pages 등에 배포

---

## 🎮 플레이 방법

1. **로비**에서 닉네임 입력
2. **방 만들기** 또는 **방 코드로 참가**
3. 두 명 모두 입장 후 **덱 빌더**에서 25~30장 덱 구성
4. 배틀 시작!

### 기본 조작
- **손패 카드 클릭** → 소환/세트 메뉴
- **내 필드 카드 클릭** → 공격/표시 변경 메뉴
- **상대 카드 클릭** (공격 선택 후) → 전투
- **드로우** 버튼 → 카드 드로우
- **턴 종료** 버튼 → 턴 넘기기

---

## 📜 게임 규칙 요약

| 항목 | 규칙 |
|------|------|
| 초기 HP | 12,000 |
| 덱 구성 | 25~30장 |
| 시작 손패 | 5장 |
| 손패 제한 | 6장 |
| 일반 소환 | 1턴 1회, 1~5성 |
| 특수 소환 | 제물 합산 > 대상 합산 |
| 선공 패널티 | 드로우 불가 + 공격 불가 |
| 직접 공격 | 상대 필드 완전 비었을 때만 |
